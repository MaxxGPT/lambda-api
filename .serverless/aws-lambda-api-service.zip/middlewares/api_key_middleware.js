const User = require('../models/user.model'),
connectToDatabase = require('../db');

exports.ApiMiddleware = async (event, context) => {
    console.log("Entro al API")
    new Promise(function(resolve, reject) {
      connectToDatabase()
      .then(() => {
          let params = event.queryStringParameters ? event.queryStringParameters : {};
          User.findOne(
              {
                apiKey: params.api_key,
              },
              (err, _user) => {
                if (err) {
                  console.log("Entro al API Error 2")
                  context.end();
                  reject({
                      statusCode: 403,
                      body: err,
                  });
                } else if (!_user) {
                  context.end();
                  console.log("Entro al API Error 3")
                  reject({
                      statusCode: 403,
                      body: 'Api Key invalid',
                  });
                } else {
                  console.log("Entro al API ëxito")
                  resolve();
                }
              }
            );
      })
      .catch((error)=>{
          context.end();
          console.log("Entro al API Error 1", error);
          reject({
              statusCode: 403,
              body: 'No results',
          });
      })
    });
 };